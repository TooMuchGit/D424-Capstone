package com.example.myapplication.adapters;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.models.Vacation;

import java.util.ArrayList;
import java.util.List;

public class VacationAdapter extends RecyclerView.Adapter<VacationAdapter.VacationViewHolder> {

    private static final String TAG = "VacationAdapter";

    private final List<Vacation> vacationList = new ArrayList<>();
    private final Context context;

    private OnItemClickListener itemListener;
    private OnVacationEditListener editListener;
    private OnShareClickListener shareListener;
    private OnExcursionClickListener excursionListener;
    private boolean editMode = false;

    public interface OnItemClickListener {
        void onClick(Vacation vacation);
    }

    public interface OnVacationEditListener {
        void onVacationEdit(Vacation vacation);
    }

    public interface OnShareClickListener {
        void onShareClick(Vacation vacation);
    }

    public interface OnExcursionClickListener {
        void onExcursionClick(Vacation vacation);
    }

    public VacationAdapter(Context context) {
        Log.d(TAG, "VacationAdapter initialized");
        this.context = context;
    }

    static class VacationViewHolder extends RecyclerView.ViewHolder {
        TextView vacationTitle, vacationLodging, vacationStartDate, vacationEndDate;
        ImageButton shareButton;
        Button excursionsButton;

        public VacationViewHolder(@NonNull View itemView) {
            super(itemView);
            vacationTitle = itemView.findViewById(R.id.vacation_title);
            vacationLodging = itemView.findViewById(R.id.vacation_lodging);
            vacationStartDate = itemView.findViewById(R.id.vacation_start_date);
            vacationEndDate = itemView.findViewById(R.id.vacation_end_date);
            shareButton = itemView.findViewById(R.id.share_vacation);
            excursionsButton = itemView.findViewById(R.id.excursions);
        }
    }

    @NonNull
    @Override
    public VacationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Log.d(TAG, "onCreateViewHolder: Creating new ViewHolder");
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_vacation, parent, false);
        return new VacationViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull VacationViewHolder holder, int position) {
        Vacation vacation = vacationList.get(position);
        Log.d(TAG, "onBindViewHolder: Binding vacation at position " + position);

        holder.vacationTitle.setText(vacation.getTitle());
        holder.vacationLodging.setText(vacation.getLodging());
        holder.vacationStartDate.setText(vacation.getStartDateFormatted());
        holder.vacationEndDate.setText(vacation.getEndDateFormatted());

        holder.shareButton.setOnClickListener(v -> {
            if (shareListener != null) {
                shareListener.onShareClick(vacation);
            }
        });

        holder.excursionsButton.setOnClickListener(v -> {
            if (excursionListener != null) {
                excursionListener.onExcursionClick(vacation);
            }
        });

        holder.itemView.setOnClickListener(v -> {
            if (editMode && editListener != null) {
                editListener.onVacationEdit(vacation);
            } else if (itemListener != null) {
                itemListener.onClick(vacation);
            }
        });
    }

    @Override
    public int getItemCount() {
        return vacationList.size();
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.itemListener = listener;
    }

    public void setOnVacationEditListener(OnVacationEditListener listener) {
        this.editListener = listener;
    }

    public void setOnShareClickListener(OnShareClickListener listener) {
        this.shareListener = listener;
    }

    public void setOnExcursionListener(OnExcursionClickListener listener) {
        this.excursionListener = listener;
    }

    public void setVacations(List<Vacation> vacations) {
        Log.d(TAG, "setVacations: Received " + vacations.size() + " items");
        vacationList.clear();
        vacationList.addAll(vacations);
        notifyDataSetChanged();
    }

    public void setEditMode(boolean editMode) {
        this.editMode = editMode;
        notifyDataSetChanged();
    }
}
