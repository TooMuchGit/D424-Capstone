package com.example.myapplication;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.adapters.ReportAdapter;
import com.example.myapplication.models.Vacation;
import com.example.myapplication.repo.VacationPlannerRepository;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class ReportActivity extends AppCompatActivity {

    private TextView reportTitle;
    private TextView reportTimestamp;
    private RecyclerView reportRecyclerView;
    private VacationPlannerRepository vacationRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        reportTitle = findViewById(R.id.report_title);
        reportTimestamp = findViewById(R.id.report_timestamp);
        reportRecyclerView = findViewById(R.id.report_recycler_view);

        // Set title and timestamp
        reportTitle.setText("Vacation Report");
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        reportTimestamp.setText("Generated: " + timestamp);

        // Set up RecyclerView
        reportRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Fetch data and populate report
        vacationRepository = VacationPlannerRepository.getInstance(getApplicationContext());
        vacationRepository.getAllVacations(vacations -> {
            ReportAdapter adapter = new ReportAdapter(vacations);
            reportRecyclerView.setAdapter(adapter);
        });


    }
}
