package com.example.myapplication.data;

import android.content.Context;

import androidx.room.Room;

public class AppDatabaseProvider {
    private static AppDatabase instance;

    public static AppDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(
                            context.getApplicationContext(),
                            AppDatabase.class,
                            "vacation_planner.db"
                    )
                    .fallbackToDestructiveMigration() // This is meant to clear data on schema mismatches. Schemas are required per the rubric, but everything runs much smoother with them.
                    .build();
        }
        return instance;
    }
}
