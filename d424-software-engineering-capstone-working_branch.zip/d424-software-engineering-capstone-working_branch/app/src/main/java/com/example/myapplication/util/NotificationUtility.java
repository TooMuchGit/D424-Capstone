package com.example.myapplication.util;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.example.myapplication.R;

public class NotificationUtility {

    // constants
    private static final String TAG = "NotificationUtility";
    private static final String CHANNEL_ID = "vacation_alert_channel";
    private static final String CHANNEL_NAME = "Vacation Alerts";
    private static final String NOTIFICATION_TITLE = "Vacation Alert";


    // variables
    private static boolean notificationsEnabled = true;


    // custom methods
    public static void setNotificationsEnabled(boolean isEnabled) {
        Log.d(TAG, "setNotificationsEnabled: " + (isEnabled ? "Enabling" : "Disabling") + " notifications.");
        notificationsEnabled = isEnabled;
    }

    public static boolean areNotificationsEnabled() {
        Log.d(TAG, "areNotificationsEnabled: " + (notificationsEnabled ? "Notifications are enabled" : "Notifications are disabled"));
        return notificationsEnabled;
    }

    public static void showVacationNotification(Context context, String vacationTitle, String message) {
        Log.d(TAG, "showVacationNotification: Checking if notifications are enabled for vacation: " + vacationTitle);
        if (areNotificationsEnabled()) {
            Log.d(TAG, "showVacationNotification: Notifications are enabled. Showing notification for vacation: " + vacationTitle);
            sendNotification(context, vacationTitle, message);
        } else {
            Log.d(TAG, "showVacationNotification: Notifications are disabled. Skipping notification for vacation: " + vacationTitle);
        }
    }

    public static void showExcursionNotification(Context context, String excursionTitle, String message) {
        Log.d(TAG, "showExcursionNotification: Checking if notifications are enabled for excursion: " + excursionTitle);
        if (areNotificationsEnabled()) {
            Log.d(TAG, "showExcursionNotification: Notifications are enabled. Showing notification for excursion: " + excursionTitle);
            sendNotification(context, excursionTitle, message);
        } else {
            Log.d(TAG, "showExcursionNotification: Notifications are disabled. Skipping notification for excursion: " + excursionTitle);
        }
    }

    private static void sendNotification(Context context, String title, String message) {
        Log.d(TAG, "sendNotification: Sending notification for: " + title);
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        Log.d(TAG, "sendNotification: NotificationManager initialized. Creating notification channel.");
        NotificationChannel channel = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            channel = new NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(channel);
        }

        Notification notification = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.vacation_icon)
                .setContentTitle(NOTIFICATION_TITLE)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build();
        Log.d(TAG, "sendNotification: Notification built. Sending notification.");
        notificationManager.notify(1, notification);
    }
}