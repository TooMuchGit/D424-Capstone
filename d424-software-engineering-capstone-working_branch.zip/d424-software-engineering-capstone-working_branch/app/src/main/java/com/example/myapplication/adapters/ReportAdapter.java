package com.example.myapplication.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.models.Vacation;

import java.util.List;

public class ReportAdapter extends RecyclerView.Adapter<ReportAdapter.ReportViewHolder> {

    private final List<Vacation> vacationList;

    public ReportAdapter(List<Vacation> vacationList) {
        this.vacationList = vacationList;
    }

    @NonNull
    @Override
    public ReportViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.report_row, parent, false);
        return new ReportViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReportViewHolder holder, int position) {
        Vacation vacation = vacationList.get(position);
        holder.titleText.setText(vacation.getTitle());
        holder.startDateText.setText(vacation.getStartDateFormatted());
        holder.endDateText.setText(vacation.getEndDateFormatted());
        holder.lodgingText.setText(vacation.getLodging());
    }

    @Override
    public int getItemCount() {
        return vacationList.size();
    }

    static class ReportViewHolder extends RecyclerView.ViewHolder {
        TextView titleText, startDateText, endDateText, lodgingText;

        public ReportViewHolder(@NonNull View itemView) {
            super(itemView);
            titleText = itemView.findViewById(R.id.report_row_title);
            startDateText = itemView.findViewById(R.id.report_row_start_date);
            endDateText = itemView.findViewById(R.id.report_row_end_date);
            lodgingText = itemView.findViewById(R.id.report_row_lodging);
        }
    }
}
