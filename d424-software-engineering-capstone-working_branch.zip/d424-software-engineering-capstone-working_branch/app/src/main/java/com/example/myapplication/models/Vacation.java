package com.example.myapplication.models;

import static com.example.myapplication.repo.Converters.DATE_FORMAT;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import com.example.myapplication.repo.Converters;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Entity
@TypeConverters(Converters.class)
public class Vacation extends Trip {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private long id;

    @ColumnInfo(name = "lodging")
    private String lodging;

    // Room requires a no-arg constructor
    public Vacation() {
        super("", null); // default values for Room
    }

    @Ignore
    public Vacation(String title, String lodging, LocalDate startDate, LocalDate endDate) {
        super(title, startDate);
        this.lodging = lodging;
        this.endDate = endDate;
    }

    @Override
    public String getTripType() {
        return "Vacation";
    }

    // Additional field not in Trip
    @ColumnInfo(name = "end_date")
    private LocalDate endDate;

    // Getters and setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getLodging() {
        return lodging;
    }

    public void setLodging(String lodging) {
        this.lodging = lodging;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public String getEndDateFormatted() {
        return endDate != null ? endDate.format(DATE_FORMAT) : "Not Set";
    }
}