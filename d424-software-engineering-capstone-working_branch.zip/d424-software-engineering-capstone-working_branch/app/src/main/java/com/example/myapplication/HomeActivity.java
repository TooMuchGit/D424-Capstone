package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {


    // constants
    private static final String TAG = "HomeActivity";


    // override methods
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Log.d(TAG, "onCreate: HomeActivity started");

        // Set a click listener on the root view which navigates to VacationActivity
        View rootView = findViewById(R.id.home_root_view);
        rootView.setOnClickListener(v -> {
            Log.d(TAG, "onCreate: Screen tapped, navigating to VacationActivity");
            Intent intent = new Intent(HomeActivity.this, VacationActivity.class);
            startActivity(intent);
            finish();
        });
        // Sets up a 'Generate Report' button
        Button reportButton = findViewById(R.id.btn_generate_report);
        reportButton.setOnClickListener(v -> {
            Log.d(TAG, "onCreate: Generate Report button clicked");
            Intent intent = new Intent(HomeActivity.this, ReportActivity.class);
            startActivity(intent);
        });
    }
}
