package com.example.myapplication.data;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import com.example.myapplication.data.Note;
import com.example.myapplication.data.NoteDao;
import com.example.myapplication.models.Vacation;
import com.example.myapplication.models.Excursion;
import com.example.myapplication.repo.VacationDao;
import com.example.myapplication.repo.ExcursionDao;
import com.example.myapplication.repo.Converters;

@Database(entities = {Note.class, Vacation.class, Excursion.class}, version = 2)
@TypeConverters(Converters.class)
public abstract class AppDatabase extends RoomDatabase {
    public abstract NoteDao noteDao();
    public abstract VacationDao vacationDao();
    public abstract ExcursionDao excursionDao();
}
