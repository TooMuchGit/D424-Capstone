package com.example.myapplication.models;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public abstract class Trip {

    protected String title;
    protected LocalDate startDate;

    // Shared date formatter
    protected static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public Trip(String title, LocalDate startDate) {
        this.title = title;
        this.startDate = startDate;
    }

    // Abstract method to identify trip type
    public abstract String getTripType();

    // Getters
    public String getTitle() {
        return title;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public String getStartDateFormatted() {
        return startDate != null ? startDate.format(DATE_FORMAT) : "Not Set";
    }

    // Optional setters if needed
    public void setTitle(String title) {
        this.title = title;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }
}
