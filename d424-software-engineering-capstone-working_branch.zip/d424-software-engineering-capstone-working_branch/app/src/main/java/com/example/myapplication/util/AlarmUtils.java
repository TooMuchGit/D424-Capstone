package com.example.myapplication.util;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.example.myapplication.receivers.AlertReceiver;

public class AlarmUtils {

    private static final String TAG = "AlarmUtils";

    public static void setVacationAlert(Context context, long triggerMillis, String title, String type) {
        Log.d(TAG, "setVacationAlert: Scheduling alert for \"" + title + "\" (" + type + ") at " + triggerMillis);

        Intent intent = new Intent(context, AlertReceiver.class);
        intent.putExtra("title", title);
        intent.putExtra("type", type);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                (int) System.currentTimeMillis(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent);
            Log.d(TAG, "setVacationAlert: Alarm scheduled.");
        } else {
            Log.e(TAG, "setVacationAlert: AlarmManager is null!");
        }
    }

    public static void setExcursionAlert(Context context, com.example.myapplication.models.Excursion excursion) {
        Log.d(TAG, "setExcursionAlert: Scheduling alert for excursion \"" + excursion.getTitle() + "\" on " + excursion.getStartDateFormatted());

        long triggerMillis = excursion.getStartDate()
                .atStartOfDay(java.time.ZoneId.systemDefault())
                .toInstant()
                .toEpochMilli();

        Intent intent = new Intent(context, AlertReceiver.class);
        intent.putExtra("title", excursion.getTitle());
        intent.putExtra("type", "excursion");

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                (int) excursion.getId(), // Unique request code per excursion
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent);
            Log.d(TAG, "setExcursionAlert: Alarm scheduled.");
        } else {
            Log.e(TAG, "setExcursionAlert: AlarmManager is null!");
        }
    }

}
