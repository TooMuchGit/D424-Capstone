package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.adapters.ExcursionAdapter;
import com.example.myapplication.fragments.ExcursionDialogFragment;
import com.example.myapplication.fragments.VacationDialogFragment;
import com.example.myapplication.models.Vacation;
import com.example.myapplication.repo.VacationPlannerRepository;
import com.example.myapplication.util.AlarmUtils;

import java.util.Objects;
import java.time.ZoneId;

public class VacationDetailActivity extends AppCompatActivity {

    private static final String TAG = "VacationDetailActivity";
    private static final String DETAILS_TITLE_BAR = "Vacation Details";

    private TextView titleTextView, lodgingTextView, startDateTextView, endDateTextView;
    private ExcursionAdapter excursionAdapter;
    private Vacation currentVacation;
    private long vacationId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vacation_detail);

        setUpToolbar();

        // UI Components
        titleTextView = findViewById(R.id.detail_vacation_title);
        lodgingTextView = findViewById(R.id.detail_vacation_lodging);
        startDateTextView = findViewById(R.id.detail_vacation_start_date);
        endDateTextView = findViewById(R.id.detail_vacation_end_date);
        RecyclerView excursionsRecyclerView = findViewById(R.id.excursions_recycler_view);

        Button editButton = findViewById(R.id.button_edit_vacation);
        Button deleteButton = findViewById(R.id.button_delete_vacation);
        Button addExcursionButton = findViewById(R.id.button_add_excursion);
        Button shareButton = findViewById(R.id.button_share_vacation);
        Button startAlertBtn = findViewById(R.id.button_set_start_alert);
        Button endAlertBtn = findViewById(R.id.button_set_end_alert);

        // Recycler setup
        excursionsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        excursionAdapter = new ExcursionAdapter(this);
        excursionsRecyclerView.setAdapter(excursionAdapter);

        // Get selected vacation ID
        vacationId = getIntent().getLongExtra("vacationId", -1);
        Log.d(TAG, "onCreate: Received vacationId = " + vacationId);
        if (vacationId == -1) {
            Log.e(TAG, "Invalid vacation ID");
            finish();
            return;
        }

        // Load data
        loadVacationDetails();
        loadExcursions();

        // Button actions
        editButton.setOnClickListener(v -> launchEditDialog());
        deleteButton.setOnClickListener(v -> attemptVacationDeletion());
        addExcursionButton.setOnClickListener(v -> launchExcursionDialog());
        shareButton.setOnClickListener(v -> shareVacationDetails());

        startAlertBtn.setOnClickListener(v -> {
            if (currentVacation != null) {
                long startMillis = currentVacation.getStartDate()
                        .atStartOfDay(ZoneId.systemDefault())
                        .toInstant()
                        .toEpochMilli();

                AlarmUtils.setVacationAlert(
                        this,
                        startMillis,
                        currentVacation.getTitle(),
                        "start"
                );
                Toast.makeText(this, "Start alert set", Toast.LENGTH_SHORT).show();
            }
        });

        endAlertBtn.setOnClickListener(v -> {
            if (currentVacation != null) {
                long endMillis = currentVacation.getEndDate()
                        .atStartOfDay(ZoneId.systemDefault())
                        .toInstant()
                        .toEpochMilli();

                AlarmUtils.setVacationAlert(
                        this,
                        endMillis,
                        currentVacation.getTitle(),
                        "end"
                );
                Toast.makeText(this, "End alert set", Toast.LENGTH_SHORT).show();
            }
        });


    }

    private void loadVacationDetails() {
        VacationPlannerRepository.getInstance(this).getVacationById(vacationId, vacation -> {
            if (vacation != null) {
                currentVacation = vacation;
                runOnUiThread(() -> displayVacationDetails(vacation));
            } else {
                Log.e(TAG, "Vacation not found");
                finish();
            }
        });
    }

    private void loadExcursions() {
        VacationPlannerRepository.getInstance(this).getExcursionsForVacation(vacationId, excursions -> {
            if (excursions != null) {
                runOnUiThread(() -> excursionAdapter.setExcursions(excursions));
            }
        });
    }

    private void displayVacationDetails(Vacation vacation) {
        titleTextView.setText(vacation.getTitle());
        lodgingTextView.setText(vacation.getLodging());
        startDateTextView.setText(vacation.getStartDateFormatted());
        endDateTextView.setText(vacation.getEndDateFormatted());
    }

    private void launchEditDialog() {
        VacationDialogFragment dialog = new VacationDialogFragment();
        Bundle args = new Bundle();
        args.putString("title", currentVacation.getTitle());
        args.putString("lodging", currentVacation.getLodging());
        args.putString("startDate", currentVacation.getStartDate().toString());
        args.putString("endDate", currentVacation.getEndDate().toString());
        dialog.setArguments(args);
        dialog.setVacationAddedListener(updatedVacation -> {
            updatedVacation.setId(currentVacation.getId());
            VacationPlannerRepository.getInstance(this).updateVacation(updatedVacation);
            runOnUiThread(() -> {
                currentVacation = updatedVacation;
                displayVacationDetails(updatedVacation);
                Toast.makeText(this, "Vacation updated", Toast.LENGTH_SHORT).show();
            });
        });
        dialog.show(getSupportFragmentManager(), "EditVacationDialog");
    }

    private void attemptVacationDeletion() {
        if (currentVacation == null) {
            Log.e(TAG, "attemptVacationDeletion: currentVacation is null");
            return;
        }

        VacationPlannerRepository.getInstance(this).deleteVacation(currentVacation, success -> {
            if (success) {
                runOnUiThread(() -> {
                    Toast.makeText(this, "Vacation deleted", Toast.LENGTH_SHORT).show();
                    finish();
                });
            } else {
                runOnUiThread(() ->
                        Toast.makeText(this, "Cannot delete vacation with excursions", Toast.LENGTH_LONG).show()
                );
            }
        });
    }

    private void launchExcursionDialog() {
        ExcursionDialogFragment dialog = new ExcursionDialogFragment(vacationId);
        dialog.setExcursionAddedListener(excursion -> {
            VacationPlannerRepository.getInstance(this).addExcursion(excursion, id -> {
                loadExcursions();
                runOnUiThread(() ->
                        Toast.makeText(this, "Excursion added", Toast.LENGTH_SHORT).show()
                );
            });
        });
        dialog.show(getSupportFragmentManager(), "AddExcursionDialog");
    }

    private void shareVacationDetails() {
        if (currentVacation == null) return;

        String shareText = "Vacation: " + currentVacation.getTitle() + "\n" +
                "Lodging: " + currentVacation.getLodging() + "\n" +
                "Start Date: " + currentVacation.getStartDateFormatted() + "\n" +
                "End Date: " + currentVacation.getEndDateFormatted();

        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);
        startActivity(Intent.createChooser(shareIntent, "Share vacation via"));
    }

    private void setUpToolbar() {
        Toolbar toolbar = findViewById(R.id.details_toolbar);
        toolbar.setTitle(DETAILS_TITLE_BAR);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(android.view.MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
