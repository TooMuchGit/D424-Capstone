package com.example.myapplication.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;
import android.util.Log;

public class AlertReceiver extends BroadcastReceiver {

    private static final String TAG = "AlertReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        String title = intent.getStringExtra("title");
        String type = intent.getStringExtra("type");

        String message;
        if("excursion".equals(type)) {
            message = "Excursion \"" + title + "\" is happening today!";
        } else {
            message = "Vacation \"" + title + "\" is " + (type.equals("start") ? "starting today!" : "ending today!");
        }

        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
        Log.d(TAG, "Alert triggered: " + message);
    }
}