package com.example.myapplication.models;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Ignore;
import androidx.room.Index;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import com.example.myapplication.repo.Converters;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Entity(foreignKeys = @ForeignKey(entity = Vacation.class, parentColumns = "id", childColumns = "vacation_id", onDelete = ForeignKey.RESTRICT), indices = {@Index("vacation_id")})
@TypeConverters(Converters.class)
public class Excursion extends Trip {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private long id;

    @ColumnInfo(name = "vacation_id")
    private long vacationId;

    // Room requires a no-arg constructor
    public Excursion() {
        super("", null); // default values for Room
    }

    @Ignore
    public Excursion(String title, long vacationId, LocalDate date) {
        super(title, date);
        this.vacationId = vacationId;
    }

    @Override
    public String getTripType() {
        return "Excursion";
    }

    // Getters and setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getVacationId() {
        return vacationId;
    }

    public void setVacationId(long vacationId) {
        this.vacationId = vacationId;
    }
}