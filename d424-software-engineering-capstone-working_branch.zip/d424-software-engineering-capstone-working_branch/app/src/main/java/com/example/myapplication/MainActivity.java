package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.content.Intent;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.myapplication.data.AppDatabaseProvider;
import com.example.myapplication.fragments.VacationDialogFragment;
import com.example.myapplication.models.Vacation;
import com.example.myapplication.data.AppDatabase;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button openDialogButton = findViewById(R.id.open_dialog_button);
        openDialogButton.setOnClickListener(v -> {
            VacationDialogFragment dialog = new VacationDialogFragment();
            dialog.setVacationAddedListener(new VacationDialogFragment.OnVacationAddedListener() {
                @Override
                public void onVacationAdded(Vacation vacation) {
                    Log.d(TAG, "Received vacation from dialog: " + vacation);

                    new Thread(() -> {
                        AppDatabase db = AppDatabaseProvider.getInstance(MainActivity.this);
                        long id = db.vacationDao().addVacation(vacation);
                        Log.d(TAG, "Vacation saved with ID: " + id);

                        runOnUiThread(() -> {
                            Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                            startActivity(intent);
                            finish();
                        });
                    }).start();
                }
            });

            dialog.show(getSupportFragmentManager(), "VacationDialog");
        });
    }
}
