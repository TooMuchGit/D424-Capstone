package com.example.myapplication.dao;

import static org.junit.Assert.*;

import android.content.Context;

import androidx.room.Room;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.myapplication.models.Vacation;
import com.example.myapplication.repo.VacationPlannerDatabase;
import com.example.myapplication.repo.VacationDao;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.time.LocalDate;
import java.util.List;

@RunWith(AndroidJUnit4.class)
public class VacationDaoTest {

    private VacationPlannerDatabase db;
    private VacationDao vacationDao;

    @Before
    public void setUp() {
        Context context = ApplicationProvider.getApplicationContext();
        db = Room.inMemoryDatabaseBuilder(context, VacationPlannerDatabase.class)
                .allowMainThreadQueries()
                .build();
        vacationDao = db.vacationDao();
    }

    @After
    public void tearDown() {
        db.close();
    }

    @Test
    public void testInsertAndRetrieveVacation() {
        Vacation vacation = new Vacation("Beach Trip", "Ocean View",
                LocalDate.of(2025, 6, 1), LocalDate.of(2025, 6, 7));
        long id = vacationDao.addVacation(vacation);

        Vacation retrieved = vacationDao.getVacationById(id);
        assertNotNull(retrieved);
        assertEquals("Beach Trip", retrieved.getTitle());
        assertEquals("Ocean View", retrieved.getLodging());
        assertEquals(LocalDate.of(2025, 6, 7), retrieved.getEndDate());
    }

    @Test
    public void testSearchVacations() {
        vacationDao.addVacation(new Vacation("Mountain Retreat", "Cabin",
                LocalDate.of(2025, 7, 1), LocalDate.of(2025, 7, 5)));
        vacationDao.addVacation(new Vacation("City Escape", "Hotel",
                LocalDate.of(2025, 8, 10), LocalDate.of(2025, 8, 15)));

        List<Vacation> results = vacationDao.searchVacations("Mountain");
        assertEquals(1, results.size());
        assertEquals("Mountain Retreat", results.get(0).getTitle());
    }

    @Test
    public void testUpdateVacation() {
        Vacation vacation = new Vacation("Old Title", "Old Lodging",
                LocalDate.of(2025, 9, 1), LocalDate.of(2025, 9, 5));
        long id = vacationDao.addVacation(vacation);

        vacation.setId(id);
        vacation.setTitle("New Title");
        vacation.setLodging("New Lodging");
        vacationDao.updateVacation(vacation);

        Vacation updated = vacationDao.getVacationById(id);
        assertEquals("New Title", updated.getTitle());
        assertEquals("New Lodging", updated.getLodging());
    }

    @Test
    public void testDeleteVacation() {
        Vacation vacation = new Vacation("Delete Me", "Nowhere",
                LocalDate.of(2025, 10, 1), LocalDate.of(2025, 10, 5));
        long id = vacationDao.addVacation(vacation);

        vacation.setId(id);
        vacationDao.deleteVacation(vacation);

        Vacation deleted = vacationDao.getVacationById(id);
        assertNull(deleted);
    }
}
