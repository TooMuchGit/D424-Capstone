package com.example.myapplication;

import static org.junit.Assert.assertEquals;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.WorkRequest;
import androidx.work.WorkInfo;
import androidx.work.testing.WorkManagerTestInitHelper;

import com.example.myapplication.workers.VacationNotificationWorker;
import com.example.myapplication.workers.ExcursionNotificationWorker;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.TimeUnit;

@RunWith(AndroidJUnit4.class)
public class NotificationSystemTest {

    private Context context;
    private WorkManager workManager;

    @Before
    public void setUp() {
        // Initialize test context and WorkManager
        context = ApplicationProvider.getApplicationContext();
        WorkManagerTestInitHelper.initializeTestWorkManager(context);
        workManager = WorkManager.getInstance(context);
    }

    @Test
    public void testVacationNotificationWorker() throws Exception {
        // This is used to create a OneTimeWorkRequest for the VacationNotificationWorker
        WorkRequest vacationWorkRequest = new OneTimeWorkRequest.Builder(VacationNotificationWorker.class)
                .setInitialDelay(0, TimeUnit.SECONDS)
                .build();

        workManager.enqueue(vacationWorkRequest).getResult().get();

        WorkManagerTestInitHelper.getTestDriver(context).setAllConstraintsMet(vacationWorkRequest.getId());

        // Verify the Excursion
        WorkInfo workInfo = workManager.getWorkInfoById(vacationWorkRequest.getId()).get();
        assertEquals(WorkInfo.State.SUCCEEDED, workInfo.getState());
    }

    @Test
    public void testExcursionNotificationWorker() throws Exception {
        // Create a OneTimeWorkRequest for the ExcursionNotificationWorker
        WorkRequest excursionWorkRequest = new OneTimeWorkRequest.Builder(ExcursionNotificationWorker.class)
                .setInitialDelay(0, TimeUnit.SECONDS) // Run immediately
                .build();

        workManager.enqueue(excursionWorkRequest).getResult().get();

        WorkManagerTestInitHelper.getTestDriver(context).setAllConstraintsMet(excursionWorkRequest.getId());

        // Verify the Excursion again
        WorkInfo workInfo = workManager.getWorkInfoById(excursionWorkRequest.getId()).get();
        assertEquals(WorkInfo.State.SUCCEEDED, workInfo.getState());
    }
}